﻿using UnityEngine;
using System.Collections;

public class backgroundController : MonoBehaviour {

    private Material materialAtual;
    public float velocidade;
    private float offset;

    void Start () {
        materialAtual = GetComponent<Renderer>().material;
    }
	
	void Update () {
        offset = offset + (velocidade * Time.deltaTime);
        materialAtual.SetTextureOffset("_MainTex", new Vector2(offset, 0));
    }
}
