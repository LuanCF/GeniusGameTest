﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Threading;
using UnityEngine.EventSystems;

public class GameController : MonoBehaviour {

    private int level;
    private int pointPlayer;
    private int[] sequences;

    private const int BTN_RED = 1;
    private const int BTN_GREEN = 2;
    private const int BTN_YELLOW = 3;
    private const int BTN_BLUE = 4;

    [SerializeField] public Text txtPressStart;
    [SerializeField] public Text txtLevelCount;

    [SerializeField] public Button btnRed;
    [SerializeField] public Button btnGreen;
    [SerializeField] public Button btnYellow;
    [SerializeField] public Button btnBlue;

    public void GoToInitialScene() { Application.LoadLevel("initial"); }

    public void btnYellowPress() { checkButtonDown(BTN_YELLOW); }
    public void btnBluePress() { checkButtonDown(BTN_BLUE); }
    public void btnGreenPress() { checkButtonDown(BTN_GREEN); }
    public void btnRedPress() { checkButtonDown(BTN_RED); }

    private IEnumerator showBtnRed() { return playAnimationButton(btnRed); }
    private IEnumerator showBtnGreen() { return playAnimationButton(btnGreen); }
    private IEnumerator showBtnYellow() { return playAnimationButton(btnYellow); }
    private IEnumerator showBtnBlue() { return playAnimationButton(btnBlue); }

    public void StartGame()
    {
        Destroy(txtPressStart);
        CreateSequences();
        pointPlayer = 0;
        level = -1;
        showSequence();
    }

    private IEnumerator playAnimationButton(Button btn)
    {
        btn.animator.SetBool("animar", true);
        yield return new WaitForSeconds(1.0f);
        btn.animator.SetBool("animar", false);
        StopCoroutine("playAnimationButton");
    }

    private void showSequence()
    {
        level++;
        txtLevelCount.text = (level + 1).ToString();

        for (int i = 0; i <= level; i++)
        {
            switch (sequences[i])
            {
                case 1: StartCoroutine(showBtnRed()); break;
                case 2: StartCoroutine(showBtnGreen()); break;
                case 3: StartCoroutine(showBtnYellow()); break;
                case 4: StartCoroutine(showBtnBlue()); break;
            }
        }
    }

    //Todo novo jogo, será uma nova sequencia para jogar
    private void CreateSequences()
    {
        sequences = new int[100];
        for (int i = 0; i < 100; i++)
        {
            sequences[i] = (Random.Range(1, 5));
        }
    }

    private void checkButtonDown(int btnPress)
    {
        if (btnPress == sequences[pointPlayer])
        {
            if (pointPlayer == level) //Acertou todas as sequencias
            {
                pointPlayer = 0;
                showSequence(); //Sobe de level e mostra as sequencias novamente 
            }
            else
            {
                pointPlayer++;
            }
        }
        else
        {
            PlayerPrefs.SetInt("lastLevel", level);
            Application.LoadLevel("gameOver");
        }
    }
}
