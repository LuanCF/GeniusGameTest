﻿using UnityEngine;
using System.Collections;

public class Game : MonoBehaviour {

    public ArrayList sequences;
    private const int ID_BTN_RED = 1;
    private const int ID_BTN_GREEN = 2;
    private const int ID_BTN_YELLOW = 3;
    private const int ID_BTN_BLUE = 4;

    void Start () {

	}
	
    void Update()
    {

    }
}
