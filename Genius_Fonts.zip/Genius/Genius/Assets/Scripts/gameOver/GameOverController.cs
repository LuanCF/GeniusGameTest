﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class GameOverController : MonoBehaviour {

    public Text txtLevelPlayer;

    void Start()
    {
        int lastLevel = PlayerPrefs.GetInt("lastLevel");
        int best = PlayerPrefs.GetInt("bestLevel");
        txtLevelPlayer.text = lastLevel.ToString();

        if (lastLevel > best)
        {
            PlayerPrefs.SetInt("bestLevel", lastLevel);
        }
    }

	public void restartGame () {
        Application.LoadLevel("mainGame");
    }

    public void exitGame()
    {
        Application.Quit();
    }
}
