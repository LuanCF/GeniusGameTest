﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class LoadScoore : MonoBehaviour {

    public Text pontos;

    void Start () {
        pontos.text = PlayerPrefs.GetInt("bestLevel").ToString();
    }
	
}
