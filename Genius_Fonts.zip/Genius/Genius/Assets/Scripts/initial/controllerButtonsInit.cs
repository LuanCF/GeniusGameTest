﻿using UnityEngine;
using System.Collections;

public class controllerButtonsInit : MonoBehaviour {

    public void ExitGame()
    {
        Application.Quit();
    }

    public void PlayGame()
    {
        Application.LoadLevel("mainGame");
    }
}
